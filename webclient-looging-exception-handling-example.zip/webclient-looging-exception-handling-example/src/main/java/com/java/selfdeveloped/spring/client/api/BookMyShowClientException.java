package com.java.selfdeveloped.spring.client.api;
public class BookMyShowClientException extends Exception{

	private static final long serialVersionUID = -6743940897192598130L;

	public BookMyShowClientException(String message) {
		super(message);
	} 
}
