package com.java.selfdeveloped;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookMyShowApplicationTests {

	@Test
	void contextLoads() {
	}

}
