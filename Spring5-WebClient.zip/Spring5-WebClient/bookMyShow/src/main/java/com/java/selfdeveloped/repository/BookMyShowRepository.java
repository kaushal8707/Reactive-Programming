package com.java.selfdeveloped.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.java.selfdeveloped.model.BookRequest;

public interface BookMyShowRepository extends JpaRepository<BookRequest, Integer>{

}