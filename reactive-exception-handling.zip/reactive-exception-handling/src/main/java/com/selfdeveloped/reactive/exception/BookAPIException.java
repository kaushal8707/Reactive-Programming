package com.selfdeveloped.reactive.exception;

	public class BookAPIException extends Exception{

	    public BookAPIException(String message) {
	        super(message);
	    }
	}
	
	
