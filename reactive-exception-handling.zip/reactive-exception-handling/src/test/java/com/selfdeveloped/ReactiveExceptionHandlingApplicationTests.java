package com.selfdeveloped;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReactiveExceptionHandlingApplicationTests {

	@Test
	void contextLoads() {
	}

}
